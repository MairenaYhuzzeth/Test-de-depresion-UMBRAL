function iniciarTest() {
    // Oculta el formulario de datos
    document.getElementById("formDatos").style.display = "none";

    // Muestra las preguntas
    document.getElementById("preguntas").style.display = "block";
}

function calcularResultado() {
    let total = 0;

    let p1 = document.querySelector('input[name="p1"]:checked');
    let p2 = document.querySelector('input[name="p2"]:checked');
    let p3 = document.querySelector('input[name="p3"]:checked');

    if (!p1 || !p2 || !p3) {
        alert("Responde todas las preguntas");
        return;
    }

    total += parseInt(p1.value);
    total += parseInt(p2.value);
    total += parseInt(p3.value);

    let resultado = "";

    if (total <= 2) {
        resultado = "Nivel bajo de síntomas";
    } else if (total <= 4) {
        resultado = "Nivel moderado de síntomas";
    } else {
        resultado = "Nivel alto de síntomas. Busca ayuda profesional.";
    }

    document.getElementById("resultado").innerText = resultado;
}
